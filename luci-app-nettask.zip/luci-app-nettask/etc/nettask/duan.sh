#!/bin/sh

#常用命令（当你需要启用这个命令时只需要去除这条命令前面的#号）：

#重启无线
#wifi 

#重启网络
#/etc/init.d/network restart 

#发送请求
#curl "..." 

#清理内存
#echo 1 > /proc/sys/vm/drop_caches 

#待补充

return 0 #所有命令都要放在这条命令之前
